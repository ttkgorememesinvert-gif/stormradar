package com.stormradar.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import org.lwjgl.input.Keyboard;

import java.util.List;

public class GuiRadar extends GuiScreen {
    private long lastScan;
    private List<StormSnapshot> storms = java.util.Collections.emptyList();
    private int mode = 0; // 0 reflectivity, 1 velocity

    @Override
    public void initGui() {
        scan();
    }

    private void scan() {
        storms = Weather2Bridge.scan();
        lastScan = System.currentTimeMillis();
    }

    @Override
    public void updateScreen() {
        if (System.currentTimeMillis() - lastScan > 1000L) scan();
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws java.io.IOException {
        if (keyCode == Keyboard.KEY_ESCAPE || keyCode == Keyboard.KEY_R) {
            mc.displayGuiScreen(null);
            return;
        }
        if (keyCode == Keyboard.KEY_M) {
            mode = (mode + 1) % 2;
        }
        super.keyTyped(typedChar, keyCode);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        drawDefaultBackground();

        int left = 20, top = 20;
        int map = Math.min(width - 300, height - 70);
        if (map < 220) map = 220;

        drawRect(left, top, left + map, top + map, 0xE80A0A12);
        drawRect(left + 1, top + 1, left + map - 1, top + map - 1, 0xFF17172A);

        // Range rings
        int cx = left + map / 2;
        int cz = top + map / 2;
        for (int r = map / 6; r < map / 2; r += map / 6) {
            drawRadarCircle(cx, cz, r, 0x553A5AA8);
        }

        // Player center
        drawRect(cx - 2, cz - 2, cx + 3, cz + 3, 0xFFFFFFFF);

        EntityPlayer p = mc.player;
        for (StormSnapshot s : storms) {
            double dx = s.x - p.posX;
            double dz = s.z - p.posZ;
            double scale = (map * 0.45) / 128.0; // 128 blocks = edge of prototype scope
            int sx = cx + (int)(dx * scale);
            int sy = cz + (int)(dz * scale);

            if (sx < left || sx > left + map || sy < top || sy > top + map) continue;

            int color = mode == 0
                    ? RadarColor.colorForDbz(s.dbz)
                    : velocityColor(s.windKmh);

            int size = s.type == StormSnapshot.Type.TORNADO ? 5 :
                       s.type == StormSnapshot.Type.CYCLONE ? 4 : 3;
            drawRect(sx - size, sy - size, sx + size + 1, sy + size + 1, color);

            String label = label(s.type);
            drawString(fontRenderer, label, sx + size + 3, sy - 4, color);
        }

        int panelX = left + map + 12;
        drawRect(panelX, top, width - 20, height - 20, 0xE80A0A12);
        drawString(fontRenderer, "STORMRADAR", panelX + 10, top + 10, 0xFFFFFFFF);
        drawString(fontRenderer, "WEATHER2 REMASTERED", panelX + 10, top + 25, 0xFFAA55FF);
        drawString(fontRenderer, "MODE: " + (mode == 0 ? "REFLECTIVITY" : "VELOCITY"),
                panelX + 10, top + 48, 0xFF55FF55);
        drawString(fontRenderer, "DETECCOES: " + storms.size(), panelX + 10, top + 62, 0xFFFFFFFF);

        int y = top + 85;
        for (StormSnapshot s : storms) {
            drawString(fontRenderer, label(s.type), panelX + 10, y, typeColor(s.type));
            drawString(fontRenderer, String.format("dBZ %.0f  Vento %.0f km/h", s.dbz, s.windKmh),
                    panelX + 10, y + 12, 0xFFCCCCCC);
            drawString(fontRenderer, "Fonte: " + s.sourceClass, panelX + 10, y + 24, 0xFF777777);
            y += 42;
            if (y > height - 55) break;
        }

        drawString(fontRenderer, "M: mudar modo   R/ESC: fechar",
                left, height - 15, 0xFFAAAAAA);

        super.drawScreen(mouseX, mouseY, partialTicks);
    }

    private String label(StormSnapshot.Type t) {
        switch (t) {
            case SUPERCELL: return "SUPERCELULA";
            case TORNADO: return "TORNADO";
            case CYCLONE: return "FURACAO/CICLONE";
            case STORM: return "TEMPESTADE";
            default: return "DESCONHECIDO";
        }
    }

    private int typeColor(StormSnapshot.Type t) {
        switch (t) {
            case TORNADO: return 0xFFFF3333;
            case CYCLONE: return 0xFFCC66FF;
            case SUPERCELL: return 0xFF55FF55;
            default: return 0xFFFFFF55;
        }
    }

    private int velocityColor(float kmh) {
        if (kmh < 40) return 0xFF44CCFF;
        if (kmh < 80) return 0xFFFFFF00;
        if (kmh < 120) return 0xFFFF8800;
        if (kmh < 160) return 0xFFFF3333;
        return 0xFFFF55FF;
    }

    private void drawRadarCircle(int cx, int cy, int r, int color) {
        // Low-cost pixel circle for 1.12.2 GUI; no external rendering lib.
        for (int a = 0; a < 360; a += 3) {
            double rad = Math.toRadians(a);
            int x = cx + (int)(Math.cos(rad) * r);
            int y = cy + (int)(Math.sin(rad) * r);
            drawRect(x, y, x + 1, y + 1, color);
        }
    }
}
