package com.stormradar.client;

public class StormSnapshot {
    public enum Type { UNKNOWN, STORM, SUPERCELL, TORNADO, CYCLONE }

    public final Type type;
    public final double x, z;
    public final float dbz;
    public final float windKmh;
    public final int stage;
    public final String sourceClass;

    public StormSnapshot(Type type, double x, double z, float dbz,
                         float windKmh, int stage, String sourceClass) {
        this.type = type;
        this.x = x;
        this.z = z;
        this.dbz = dbz;
        this.windKmh = windKmh;
        this.stage = stage;
        this.sourceClass = sourceClass;
    }
}
