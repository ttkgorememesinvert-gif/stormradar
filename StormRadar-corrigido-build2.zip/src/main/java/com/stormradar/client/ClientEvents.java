package com.stormradar.client;

import com.stormradar.StormRadar;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;

@SideOnly(Side.CLIENT)
public class ClientEvents {
    private static final KeyBinding OPEN_RADAR =
            new KeyBinding("key.stormradar.open", Keyboard.KEY_R, "key.categories.misc");

    private boolean registered;

    public ClientEvents() {
        if (!registered) {
            net.minecraftforge.fml.client.registry.ClientRegistry.registerKeyBinding(OPEN_RADAR);
            registered = true;
        }
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (OPEN_RADAR.isPressed()) {
            Minecraft.getMinecraft().displayGuiScreen(new GuiRadar());
        }
    }
}
