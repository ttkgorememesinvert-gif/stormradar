package com.stormradar.client;

public final class RadarColor {
    private RadarColor() {}

    // dBZ-inspired palette matching the project's requested pixel-radar style.
    public static int colorForDbz(float dbz) {
        if (dbz < 10) return 0xFF1646D8;
        if (dbz < 20) return 0xFF159BC8;
        if (dbz < 30) return 0xFF18A83A;
        if (dbz < 35) return 0xFF7ACB18;
        if (dbz < 40) return 0xFFFFE000;
        if (dbz < 50) return 0xFFFF8A00;
        if (dbz < 60) return 0xFFFF241A;
        if (dbz < 70) return 0xFFFF35B7;
        return 0xFFF7EAF7;
    }
}
