package com.stormradar;

import com.stormradar.client.ClientEvents;
import com.stormradar.registry.ModBlocks;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = StormRadar.MODID, name = StormRadar.NAME, version = StormRadar.VERSION,
     acceptedMinecraftVersions = "[1.12.2]", dependencies = "required-after:forge")
public class StormRadar {
    public static final String MODID = "stormradar";
    public static final String NAME = "StormRadar";
    public static final String VERSION = "0.1.0";

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        ModBlocks.register();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new ClientEvents());
    }
}
