@echo off
setlocal
set APP_HOME=%~dp0
set GRADLE_VERSION=2.14.1
set DIST_URL=https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip
set CACHE_DIR=%USERPROFILE%\.gradle\wrapper\dists\stormradar-gradle-%GRADLE_VERSION%
set GRADLE_DIR=%CACHE_DIR%\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_DIR%\bin\gradle.bat" (
  echo Downloading Gradle %GRADLE_VERSION%...
  powershell -NoProfile -Command "New-Item -ItemType Directory -Force -Path '%CACHE_DIR%' | Out-Null; Invoke-WebRequest -UseBasicParsing '%DIST_URL%' -OutFile '%CACHE_DIR%\gradle.zip'; Expand-Archive -Force '%CACHE_DIR%\gradle.zip' '%CACHE_DIR%'"
)
call "%GRADLE_DIR%\bin\gradle.bat" %*
endlocal
