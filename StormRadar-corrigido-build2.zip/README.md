# StormRadar — Minecraft 1.12.2

Primeiro protótipo do addon de radar para Weather2 Remastered.

## O que já existe
- GUI de radar com estética escura/pixel.
- Modo REFLECTIVITY e VELOCITY.
- Escala de cores inspirada em dBZ.
- Detecção compatível por reflexão de entidades Weather2:
  - tornado
  - cyclone/hurricane
  - supercell
  - storm
- Painel com vento, dBZ, estágio e classe detectada.
- Bloco `weather_radar`.
- Tecla R para abrir o radar.

## Integração Weather2
Este v0.2.0 foi ajustado especificamente para o arquivo:

`Weather2Remastered-1.12.2-2.9.10hf1.jar`

A integração usa diretamente:
- `WeatherAPI.getManager(world)`
- `WeatherManager.getWeatherObjects()`
- `StormObject.isTornado()`
- `StormObject.isCyclone()`
- `StormObject.isSevere()`
- `StormObject.rain`, `rainRate`, `hail`, `hailRate`
- `StormObject.windSpeed`, `intensity`, `stage`

O dBZ é uma escala visual derivada dos valores do Weather2; não é uma medição
física de radar real. A próxima etapa é construir o mapa de ecos em pixels e
anéis de alcance, seguindo o design aprovado.

## Build
Use Java 8.

    gradlew setupDecompWorkspace
    gradlew build

O jar será criado em `build/libs/`.

## Dependência em jogo
- Minecraft Forge 1.12.2
- Weather2 Remastered 1.12.2
- Coroutil, conforme exigido pelo Weather2 Remastered.
