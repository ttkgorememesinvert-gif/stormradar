package com.stormradar.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.World;
import net.mrbt0907.weather2.api.WeatherAPI;
import net.mrbt0907.weather2.weather.WeatherManager;
import net.mrbt0907.weather2.weather.storm.StormObject;
import net.mrbt0907.weather2.weather.storm.WeatherObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Direct integration with Weather2 Remastered 1.12.2 2.9.10hf1.
 *
 * Verified against the exact Weather2 jar supplied with this project:
 * WeatherAPI.getManager(World)
 * WeatherManager.getWeatherObjects()
 * StormObject.isTornado()
 * StormObject.isCyclone()
 * StormObject.isSevere()
 * StormObject.rain / hail / windSpeed / intensity / stage / type
 */
public final class Weather2Bridge {
    private Weather2Bridge() {}

    public static List<StormSnapshot> scan() {
        List<StormSnapshot> out = new ArrayList<StormSnapshot>();
        Minecraft mc = Minecraft.getMinecraft();
        World world = mc.world;
        if (world == null) return out;

        WeatherManager manager;
        try {
            manager = WeatherAPI.getManager(world);
        } catch (Throwable t) {
            return out;
        }
        if (manager == null) return out;

        for (WeatherObject object : manager.getWeatherObjects()) {
            if (!(object instanceof StormObject)) continue;

            StormObject storm = (StormObject)object;
            if (storm.isDead || storm.isDying || storm.pos == null) continue;

            StormSnapshot.Type type = classify(storm);
            if (type == StormSnapshot.Type.UNKNOWN) continue;

            float dbz = estimateDbz(storm);
            float windKmh = Math.max(0F, storm.windSpeed) * 3.6F;

            out.add(new StormSnapshot(
                    type,
                    storm.pos.xCoord,
                    storm.pos.zCoord,
                    dbz,
                    windKmh,
                    storm.stage,
                    storm.getTypeName()
            ));
        }
        return out;
    }

    private static StormSnapshot.Type classify(StormObject storm) {
        if (storm.isTornado()) return StormSnapshot.Type.TORNADO;
        if (storm.isCyclone()) return StormSnapshot.Type.CYCLONE;

        // Weather2 2.9.10hf1 exposes severe/violent storm state rather than
        // a dedicated public "isSupercell()" method. We label severe storms
        // as SUPERCELL in the radar UI until a future addon detector uses
        // storm morphology/rotation criteria.
        if (storm.isSevere() || storm.isViolent) return StormSnapshot.Type.SUPERCELL;
        if (storm.isStorm()) return StormSnapshot.Type.STORM;
        return StormSnapshot.Type.UNKNOWN;
    }

    /**
     * Weather2 exposes rain/rainRate/hail/hailRate/intensity rather than dBZ.
     * This maps those native intensity values into the requested visual dBZ
     * palette. It is intentionally a display index, not scientific radar data.
     */
    private static float estimateDbz(StormObject storm) {
        float rain = clamp01(Math.max(storm.rain, storm.rainRate));
        float hail = clamp01(Math.max(storm.hail, storm.hailRate));
        float intensity = clamp01(storm.intensity);
        float wind = Math.min(Math.max(storm.windSpeed, 0F) / 35F, 1F);

        float dbz = 8F
                + rain * 32F
                + intensity * 20F
                + hail * 20F
                + wind * 8F;

        if (storm.isTornado()) dbz += 8F;
        if (storm.isCyclone()) dbz += 4F;

        return Math.min(75F, Math.max(5F, dbz));
    }

    private static float clamp01(float v) {
        return Math.max(0F, Math.min(1F, v));
    }
}
