package com.stormradar.registry;

import com.stormradar.StormRadar;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.fml.common.registry.ForgeRegistries;

public final class ModBlocks {
    public static Block RADAR;

    private ModBlocks() {}

    public static void register() {
        RADAR = new BlockRadar(Material.IRON)
                .setRegistryName(StormRadar.MODID, "weather_radar")
                .setUnlocalizedName(StormRadar.MODID + ".weather_radar")
                .setCreativeTab(CreativeTabs.REDSTONE);

        ForgeRegistries.BLOCKS.register(RADAR);
        ForgeRegistries.ITEMS.register(new ItemBlockRadar(RADAR));
    }

    public static class BlockRadar extends Block {
        public BlockRadar(Material material) {
            super(material);
            setHardness(3.0F);
            setResistance(10.0F);
        }
    }

    public static class ItemBlockRadar extends Item {
        public ItemBlockRadar(Block block) {
            setRegistryName(block.getRegistryName());
            setUnlocalizedName(block.getUnlocalizedName());
            setCreativeTab(CreativeTabs.REDSTONE);
        }
    }
}
